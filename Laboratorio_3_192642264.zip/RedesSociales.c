#include "funciones.h"

int main(int argc, char const *argv[]) {
  iniciar();
  return 0;
}
